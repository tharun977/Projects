part of 'channelpage_bloc.dart';

abstract class ChannelPageEvent extends Equatable {
  const ChannelPageEvent();

  @override
  List<Object> get props => [];
}

class GetChannelListData extends ChannelPageEvent {
  const GetChannelListData();

  @override
  List<Object> get props => [];
}
