package com.example.lavender

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
